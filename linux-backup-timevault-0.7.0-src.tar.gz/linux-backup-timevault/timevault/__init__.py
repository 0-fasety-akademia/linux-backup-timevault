__version__ = "0.7.0"
APP_NAME = "Linux Backup TimeVault"
